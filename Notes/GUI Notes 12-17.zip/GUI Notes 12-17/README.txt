Behavior of GUI and hierarchy involved:

GUI components are in Controllers/Menus folder.

A ShipController is the graphical frontend to the Ship class in the backend.
As such, a ShipController has a Ship.  Similar for HexController and GameboardController.

Nearly all functionality should be kept in the menu classes.
Let me know if you need to modify any of the Controller classes.

You can call ShipController.fire(ShipController other) where the fire menu instructs its ShipController to fire.

This is a fairly open-ended task, and all you've really got is the little bit I've already done.

Text me if you need any clarification.

I'm curious to hear about what design you come up with.  Good Luck.
-Dave